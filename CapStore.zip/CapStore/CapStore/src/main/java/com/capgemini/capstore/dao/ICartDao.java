package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Customer;
@Repository
public interface ICartDao extends JpaRepository<Cart,Long>{
	@Query("from Cart where customer=?1")
	List<Cart> getCartByCustomerId(Customer customer);

}
