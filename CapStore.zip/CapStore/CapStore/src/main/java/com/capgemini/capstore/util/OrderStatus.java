package com.capgemini.capstore.util;

public enum OrderStatus {
	Placed, Ready, Shipped, Delivered;
}