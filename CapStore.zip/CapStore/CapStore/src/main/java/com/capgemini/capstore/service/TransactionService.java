package com.capgemini.capstore.service;

import java.util.List;
import java.util.Optional;

import org.hibernate.TransactionException;

import com.capgemini.capstore.beans.AccountDetail;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Stock;

public interface TransactionService {

	AccountDetail addAccountDetails(AccountDetail accountDetail, long customerId) throws TransactionException;



	List<AccountDetail> getAllAccounts() throws TransactionException;

	
	





	void deleteAccountById(long cardNo) throws TransactionException;





	AccountDetail updateAccountDetails(long cardNo, double finalAmount);



	AccountDetail getTransactionByCustomerId(long customerId);





}
