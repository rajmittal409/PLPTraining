package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.IMerchantDao;
import com.capgemini.capstore.util.Decryption;
import com.capgemini.capstore.util.Encryption;

@Service
public class MerchantServiceImpl implements IMerchantService{
		
	@Autowired
	IMerchantDao merchantDao;

	@Override
	public Merchant createAccount(Merchant merchant) {
		merchant.setMerchantPassword(Encryption.encrypt(merchant.getMerchantPassword()));
		merchantDao.save(merchant);
		return merchantDao.findById(merchant.getMerchantId()).get();
	}

	@Override
	public Merchant viewById(long merchantId) {
		Merchant merchant=  merchantDao.findByMerchantId(merchantId);
		merchant.setMerchantPassword(Decryption.decrypt(merchant.getMerchantPassword()));
		return merchant;
	}
	
}
