package com.capgemini.capstore.service;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.DeliveryStatus;
import com.capgemini.capstore.beans.Invoice;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.beans.Order;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Stock;
import com.capgemini.capstore.dao.ICartDao;
import com.capgemini.capstore.dao.ICouponDao;
import com.capgemini.capstore.dao.ICustomerDao;
import com.capgemini.capstore.dao.IDeliveryStatusDao;
import com.capgemini.capstore.dao.IInvoiceDao;
import com.capgemini.capstore.dao.IMerchantDao;
import com.capgemini.capstore.dao.IOrderDao;
import com.capgemini.capstore.dao.IProductDao;
import com.capgemini.capstore.dao.IStockDao;
import com.capgemini.capstore.util.Encryption;
import com.capgemini.capstore.util.OrderStatus;
@Service
public class InvoiceServiceImpl implements IInvoiceService {

	@Autowired
	IInvoiceDao invoiceDao;
	
	@Autowired
	IMerchantDao merchantDao;
	
	@Autowired
	ICartDao cartDao;
	
	
	
	@Autowired
	ICouponDao couponDao;
	
	@Autowired
	IStockDao stockDao;
	
	@Autowired
	ICustomerDao customerDao;

	@Autowired
	IOrderDao orderDao;
	
	@Autowired
	IProductDao productDao; 
	
	@Autowired
	IDeliveryStatusDao deliveryStatusDao; 
	
	@Override
	public Invoice generateInvoice(long customerId, double adminDiscount, double finalAmount) {
		// TODO Auto-generated method stub
		double totalAmount=finalAmount-(finalAmount*adminDiscount/100);
		Optional<Customer> optional=customerDao.findById(customerId);
		Customer customer=optional.get();
		Invoice invoice=new Invoice(1000, adminDiscount, totalAmount,customer);
		Invoice tempInvoice=invoiceDao.save(invoice);
		return tempInvoice;
		
	}
	
	@Override
	public DeliveryStatus generateOrder(Order order, long productId, long invoiceId) {
		// TODO Auto-generated method stub
		
		
		Optional<Invoice> optional1=invoiceDao.findById(invoiceId);
		Invoice invoice=optional1.get();
		Optional<Product> product=productDao.findById(productId);
		Product pro=product.get(); 
		order.setInvoice(invoice);
		order.setProducts(pro);
		
		Order orderTemp=orderDao.save(order);
		DateFormat df = new SimpleDateFormat("dd/MM/yy");
		Date dateobj = new Date(10);
		DeliveryStatus deliveryStatus=new DeliveryStatus();
		deliveryStatus.setDeliveryDate(dateobj);
		deliveryStatus.setOrder(orderTemp);
		deliveryStatus.setStatus(OrderStatus.Placed);
		DeliveryStatus deliveryStatus2=deliveryStatusDao.save(deliveryStatus);
		return deliveryStatus2;
	}

	@Override
	public Coupon viewByCouponCode(String couponCode) {
		// TODO Auto-generated method stub
		Coupon coupon=couponDao.findByCouponCode(couponCode);
		return coupon;
	}
	
	@Override
	public List<Coupon> viewAllCouponCode() {
		// TODO Auto-generated method stub
		List<Coupon> coupon=couponDao.findAll();
		return coupon;
	}

	@Override
	public double viewByProductId(long productId) {
		// TODO Auto-generated method stub
		Optional<Product> optional=productDao.findById(productId);
		Product product=optional.get(); 
		double productDiscount=product.getProductDiscount();
		Merchant merchant=product.getMerchant();
		double merchantDiscount=merchant.getMerchantDiscount();
		double totalDiscount=productDiscount+merchantDiscount;
	
		return totalDiscount;
	}

	@Override
	public boolean findProductQuantity(long productId, int quantity) {
		// TODO Auto-generated method stub
		 Optional<Product> optional=productDao.findById(productId);
	        Product product=optional.get();
	        Optional<Stock> stock=stockDao.getStockByProductId(product);
	        if(stock.get().getAvailable() < quantity) {
	            return false;
	        }
	        else
	        return true;
	               
	}

	@Override
    public List<List<Order>> getOrders(long customerId) {
        // TODO Auto-generated method stub
        Optional<Customer> optional=customerDao.findById(customerId);
        Customer customer=optional.get();
       
        List<List<Order>> orderTemp=null;
        List<Invoice> listInvoice= invoiceDao.getOrdersByCustomerId(customer);
        for (int i = 0; i < listInvoice.size(); i++) {
            Invoice invoice=listInvoice.get(i);
            long invoiceId=invoice.getInvoiceId();
            Optional<Invoice> optional1=invoiceDao.findById(invoiceId);
            Invoice invoice1=optional1.get();
           
            List <Order> order=orderDao.findByOrderId(invoice1);
            
          
          	orderTemp.add(order);
         
            
           
        }
        return orderTemp;
       
       
    }

	@Override
	public Invoice getInvoice(long invoiceId) {
		// TODO Auto-generated method stub
		Optional<Invoice> optional=invoiceDao.findById(invoiceId);
        Invoice invoice=optional.get();
		return invoice;
	}

	@Override
	public List<Order> getOrder(long invoiceId) {
		// TODO Auto-generated method stub
		Optional<Invoice> optional=invoiceDao.findById(invoiceId);
        Invoice invoice=optional.get();
        List <Order> order=orderDao.findByOrderId(invoice);
		return order;
	}

	@Override
	public double getPrice(long productId) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				 Optional<Product> optional=productDao.findById(productId);
			        Product product=optional.get();
			        
		return product.getProductPrice();
	}

	@Override
	public Cart generateCart(long customerId, long productId) {
		// TODO Auto-generated method stub
		   Optional<Customer> optional=customerDao.findById(customerId);
	        Customer customer=optional.get();
	       
	        
	      
	    	  Optional<Product> optional1=productDao.findById(productId);
		        Product product=optional1.get();
		        
		  Cart cart=new Cart(111,10,product,customer);      
	      
	      Cart cart1=cartDao.save(cart);
		return cart1;
	}
	
	@Override
	public List<Cart> getCart(long customerId) {
		
		 Optional<Customer> optional=customerDao.findById(customerId);
	        Customer customer=optional.get();
	        List<Cart> listCart= cartDao.getCartByCustomerId(customer);
	           
	       
		return listCart;

	}
	@Override
    public Stock updateInventory(Long productId, Integer quantity/*,Integer totalQuantity, Stock stock*/) {
        Optional<Product> optional=productDao.findById(productId);
    
        
        Product product = optional.get();
       
        Optional<Stock> prod=stockDao.getStockByProductId(product);
        Stock stock=prod.get();
        stock.setAvailable(stock.getAvailable()-quantity);
        
    return stockDao.save(stock);
    }

	

}
