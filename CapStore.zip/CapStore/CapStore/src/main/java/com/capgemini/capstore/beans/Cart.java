package com.capgemini.capstore.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "capstore_cart")
public class Cart {
	public Cart(long cartId, int productQuantity, Product products, Customer customer) {
		super();
		this.cartId = cartId;
		this.productQuantity = productQuantity;
		this.products = products;
		this.customer = customer;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cart_seq_gen")
	@SequenceGenerator(name = "cart_seq_gen", initialValue = 10000, sequenceName = "cart_seq") // to be created
	private long cartId;
	private int productQuantity;
	@OneToOne(fetch = FetchType.LAZY)
	private Product products;
	@OneToOne
	private Customer customer;
	public Cart() {
		super();
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public long getCartId() {
		return cartId;
	}
	public void setCartId(long cartId) {
		this.cartId = cartId;
	}
	public Product getProducts() {
		return products;
	}
	
	public void setProducts(Product products) {
		this.products = products;
	}
	

}
