package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Revenue;
import com.capgemini.capstore.service.IRevenueService;

@RestController
@RequestMapping("/revenue")

@CrossOrigin(origins = "http://localhost:4200")
public class RevenueController {
	
	@Autowired
	IRevenueService revenue;
	
	
	@PutMapping("/fetching/{invoiceId}")
	public Revenue getDetails(@PathVariable long invoiceId)
	{
		return revenue.getDetails(invoiceId);
		
		
	}
	
	
	
}
