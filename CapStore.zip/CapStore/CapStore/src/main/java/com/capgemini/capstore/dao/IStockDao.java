package com.capgemini.capstore.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Stock;

public interface IStockDao extends JpaRepository<Stock, Integer> {
    
    
 
    @Query("select s from Stock s where s.product=?1")
    Optional<Stock> getStockByProductId(Product product);

	
}
 




