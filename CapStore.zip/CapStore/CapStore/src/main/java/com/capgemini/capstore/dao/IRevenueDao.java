
package com.capgemini.capstore.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Invoice;
import com.capgemini.capstore.beans.Revenue;
@Repository
public interface IRevenueDao extends JpaRepository<Revenue, Long>{


	
}
