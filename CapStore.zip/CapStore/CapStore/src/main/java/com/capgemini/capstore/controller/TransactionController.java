package com.capgemini.capstore.controller;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.AccountDetail;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Stock;
import com.capgemini.capstore.service.TransactionService;
@RestController

@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:4200")
public class TransactionController {
	@Autowired
	TransactionService transactionService;

	@RequestMapping(value = "/addCard/{customerId}", method = RequestMethod.POST)
	 //@PutMapping can also be used but we don't have to write
	//method=RequestMethod.POST
	@CrossOrigin(origins = "http://localhost:4200")
	public AccountDetail addAccountDetails(@RequestBody AccountDetail accountdetail,@PathVariable long customerId) {
		return transactionService.addAccountDetails(accountdetail,customerId);
	}

	/*@RequestMapping(value = "/add/{customerId}", method = RequestMethod.POST)
	// @PutMapping can also be used but we don't have to write
	// method=RequestMethod.POST
	public List<AccountDetail> addAccountDetails(@PathVariable Customer customerId, @RequestBody AccountDetail accountdetail) throws TransactionException {
		return transactionService.addAccountDetails(customerId,accountdetail);
	}
	*/
	
	@RequestMapping(value="/updateAccountDetail/{cardNo}/{finalAmount}",method = RequestMethod.PUT)
	//@CrossOrigin(origins = "http://localhost:4200")
	public AccountDetail getAccountDetails(@PathVariable long cardNo,@PathVariable double finalAmount)
	{
		return transactionService.updateAccountDetails(cardNo,finalAmount);
	}
	

	
	@RequestMapping("/all")
	//@CrossOrigin(origins = "http://localhost:4200")
	public List<AccountDetail> getAllAccounts() {
		return transactionService.getAllAccounts();
	}

	@RequestMapping("/getAccountDetail/{customerId}")
	//@CrossOrigin(origins = "http://localhost:4200")
	public AccountDetail getTransactionByCustomerId(@PathVariable long customerId) {
		return transactionService.getTransactionByCustomerId(customerId);
	}

	@DeleteMapping("/delete/{cardNo}")
	//@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<String> deleteAccountById(@PathVariable int cardNo) {
		transactionService.deleteAccountById(cardNo);
		return new ResponseEntity<String>("Account with CardNo" + cardNo + "is deleted", HttpStatus.OK);
	}
}
