import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cart } from '../Beans/Cart';
import { GenerateInvoiceServiceService } from '../generate-invoice-service.service';
@Component({
  selector: 'app-generate-invoice',
  templateUrl: './generate-invoice.component.html',
  styleUrls: ['./generate-invoice.component.css']
})
export class GenerateInvoiceComponent implements OnInit {
  cart: Cart[] = [];
  couponDiscount: number = 0;
  couponDiscountAmount: number = 0;
  discountPercent;
  finalAmount: number = 0;
  discountAmount: number = 0;
  totalAmount: number = 0;
  couponTotal: number = 0;
  finalTotal: number = 0;
  totalAmountDiscounted: number = 0;
  productPrice: number = 0;
  productQuantity: number = 0;
  router: Router;
  discountTotal: number = 0;
  discount;
  temp: number = 0;
  amount: number = 0;;
  generateService: GenerateInvoiceServiceService
  constructor(router: Router, generateService: GenerateInvoiceServiceService) {
    this.router = router;
    this.generateService = generateService
    this.fetchDetailsA();

  }
  ngOnInit() {
    this.fetchDetailsB();

  }
  fetchDetailsA() {
    this.cart = this.generateService.cart
    console.log(this.cart)
    this.couponDiscount = this.generateService.couponDiscount;
    console.log(this.couponDiscount)
    this.discountPercent = this.generateService.discountPercent;
    console.log(this.discountPercent)
  }


  fetchDetailsB() {
    for (let product of this.cart) {
      let data3 = this.generateService.applyDiscount(product.products.productId);
      data3.subscribe(data4 => {
        console.log(data4);
        this.discountPercent = data4;

        this.productPrice = product.products.productPrice
        this.productQuantity = product.productQuantity;

        this.totalAmount = this.productPrice * this.productQuantity;
        this.amount = this.amount + this.totalAmount
        console.log(this.totalAmount)



        this.discountAmount = this.discountAmount + (this.productPrice * this.productQuantity) * (this.discountPercent / 100)
        this.discountTotal = this.discountTotal + this.discountAmount
        this.generateService.discountPercent = this.discountAmount
        this.totalAmount = this.totalAmount - this.discountAmount
        this.couponDiscountAmount = this.totalAmount * this.couponDiscount / 100
        this.couponTotal = this.couponTotal + this.couponDiscountAmount
        console.log(this.generateService.discountPercent)
        this.finalAmount = this.totalAmount - this.couponDiscountAmount
        this.finalTotal = this.finalTotal + this.finalAmount
        this.generateService.finalAmount = this.finalTotal
        this.totalAmount = 0;

      })
    }
  }

  Card() {
    alert("Redirecting to Carddetails page!! Please don't refresh")
    this.router.navigate(['app-carddetails']);
  }
  COD() {
    alert("Cash On delivery")
    this.router.navigate(['app-cashondelivery']);
  }
}
