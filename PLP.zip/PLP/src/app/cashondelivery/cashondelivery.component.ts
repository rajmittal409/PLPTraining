import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GenerateInvoiceServiceService } from '../generate-invoice-service.service';
import { AccountDetail } from '../Beans/AccountDetail';

@Component({
  selector: 'app-cashondelivery',
  templateUrl: './cashondelivery.component.html',
  styleUrls: ['./cashondelivery.component.css']
})
export class CashondeliveryComponent implements OnInit {

  generateInvoiceService: GenerateInvoiceServiceService;
  router: Router;
  accountDetails: AccountDetail;
  account;
  constructor(generateInvoice: GenerateInvoiceServiceService, router: Router) {
    this.generateInvoiceService = generateInvoice;
    this.router = router;
  }

  ngOnInit() {
    this.router.navigate(["app-invoice-bill"])
  }

}
