import { Component, OnInit } from '@angular/core';
import { GenerateInvoiceServiceService } from '../generate-invoice-service.service';
import { Router } from '@angular/router';
import { Invoice } from '../Beans/Invoice';
import { Order } from '../Beans/Order';
import { Cart } from '../Beans/Cart';

@Component({
  selector: 'app-invoice-bill',
  templateUrl: './invoice-bill.component.html',
  styleUrls: ['./invoice-bill.component.css']
})
export class InvoiceBillComponent implements OnInit {
  generateInvoiceService: GenerateInvoiceServiceService;
  router: Router;
  invoiceId: number;
  invoice: any;
  order1;
  order;
  cart: Cart[] = [];
  revenue;
  couponAmount: number;
  discountAmount: number;
  finalAmount: number;
  couponValue: number;
  coupon;
  inventary;
  discount;
  account;
  isQuantity;
  amount: number = 20000;
  stock;
  data8;
  constructor(generateInvoice: GenerateInvoiceServiceService, router: Router) {
    this.generateInvoiceService = generateInvoice;
    this.router = router;
    this.fetchCartDetail();
  }
  

  ngOnInit() {

    this.CalculateDiscounts();
  }

  fetchCartDetail() {
    this.cart = this.generateInvoiceService.cart
    console.log(this.cart)
  }
  CalculateDiscounts() {
    let data7 = this.generateInvoiceService.generateInvoice(10000, 10, this.generateInvoiceService.finalAmount);
    data7.subscribe(data4 => {
      this.invoice = data4
      this.generateInvoiceService.invoiceId = this.invoice.invoiceId;
      console.log(this.invoice)

      this.data8 = this.generateInvoiceService.generateOrder(100003, this.invoice.invoiceId);
      console.log(this.data8)


      this.invoiceId = this.generateInvoiceService.invoiceId
      
      let data1 = this.generateInvoiceService.fetchInvoice(this.invoiceId);
      data1.subscribe(data2 => {
        this.invoice = data2;
        console.log(this.invoice)


        let data13 = this.generateInvoiceService.fetchOrders(this.invoiceId);
        data13.subscribe(data2 => {
          this.order = data2;
          console.log(this.order)

          let data10 = this.generateInvoiceService.updateInventary();
          console.log(data10)
          let data3 = this.generateInvoiceService.updateRevenue(this.invoiceId);
          data3.subscribe(data2 => {
            this.revenue = data2;
            console.log(this.revenue)
            let data1 = this.generateInvoiceService.fetchAccount(10000);
            data1.subscribe(data2 => {
              this.account = data2;
              console.log(this.account)

            })
          })
        })
      })
    })


  }
}
