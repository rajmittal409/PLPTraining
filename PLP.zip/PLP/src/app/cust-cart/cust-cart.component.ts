import { Component, OnInit } from '@angular/core';
import { Product } from '../Beans/Product';
import { GenerateInvoiceServiceService } from '../generate-invoice-service.service';
import { Router } from '@angular/router';
import { Coupon } from '../Beans/Coupon';
import { Calculations } from '../Beans/Calculations';
import { Cart } from '../Beans/Cart';

@Component({
  selector: 'app-cust-cart',
  templateUrl: './cust-cart.component.html',
  styleUrls: ['./cust-cart.component.css']
})
export class CustCartComponent implements OnInit {
  generateInvoiceService: GenerateInvoiceServiceService;
  router: Router;
  returnFlag = 0;
  amount: number;
  couponAmount: number;
  discountAmount: number;
  finalAmount: number;
  couponValue: number;
  stock: String;
  coupon;
  coupons;
  discount;
  isQuantity;
  invoice;
  order;
  calculation: Calculations
  price;
  cart;
  curDate: Date;
  tempArray;
  couponDiscount: number[] = []
  calculations: Calculations[] = [];
  constructor(generateInvoice: GenerateInvoiceServiceService, router: Router) {
    this.generateInvoiceService = generateInvoice;
    this.router = router;
  }

  ngOnInit() {
    this.fetchDetails();

  }
  fetchDetails() {
    let data = this.generateInvoiceService.getCart(10000);
    data.subscribe(data2 => {
      this.cart = data2;
      console.log(this.cart)

      this.generateInvoiceService.cart = data2;
    })
    let data3 = this.generateInvoiceService.getCoupons();
    data3.subscribe(data4 => {
      this.coupons = data4;
      console.log(this.coupons)
      this.generateInvoiceService.coupons = data4;

    })
  }

  payment(data: any) {
    for (let cp of this.coupons) {
      if (data.couponCode != cp.couponCode) {
        continue;
      }
      else
        this.returnFlag++;
    }
    if (this.returnFlag == 0) {
      alert("INVALID COUPON")
      return;
    }
    for (let product of this.cart) {
      let data5 = this.generateInvoiceService.checkQuantity(product.products.productId, product.productQuantity);
      data5.subscribe(data6 => {
        this.isQuantity = data6;
        if (this.isQuantity == false) {
          this.stock = "Out"
          return;
        } else
          this.stock = "In"
      })

    }
    if (this.stock == "Out") {
      return;
    }
    else {
      let data1 = this.generateInvoiceService.applyCoupon(data.couponCode);
      data1.subscribe(data2 => {
        this.coupon = data2;
        console.log(this.coupon)
        this.curDate = new Date();
        if (this.coupon.expiryDate <= this.curDate) {
          alert("Coupon Expired")
          return;
        }
        this.couponAmount = this.coupon.discountPercent
        this.generateInvoiceService.couponDiscount = this.coupon.discountPercent
        console.log(this.generateInvoiceService.couponDiscount);


        for (let product of this.cart) {
          console.log(product)
          let data5 = this.generateInvoiceService.checkQuantity(product.products.productId, product.productQuantity);
          data5.subscribe(data6 => {
            this.isQuantity = data6;
            console.log(this.isQuantity)
            if (this.isQuantity == false) {
              this.stock = "Out"

            }
            else {

              this.amount = product.products.productPrice * product.productQuantity
              this.generateInvoiceService.amount = this.amount
              console.log(this.generateInvoiceService.amount);


              let data3 = this.generateInvoiceService.applyDiscount(product.products.productId);
              data3.subscribe(data4 => {
                console.log(data4);
                this.discount = data4;
                this.discountAmount = this.amount * (this.discount / 100)
                this.generateInvoiceService.discountPercent = this.discountAmount
                console.log(this.generateInvoiceService.discountPercent)
              })
            }
          })


        }

        this.router.navigate(["app-generate-invoice"]);

      })
    }
  }
}
