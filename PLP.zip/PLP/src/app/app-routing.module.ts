import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GenerateInvoiceComponent } from './generate-invoice/generate-invoice.component';
import { CashondeliveryComponent } from './cashondelivery/cashondelivery.component';
import { CarddetailsComponent } from './carddetails/carddetails.component';
import { CustCartComponent } from './cust-cart/cust-cart.component';
import { InvoiceBillComponent } from './invoice-bill/invoice-bill.component';


const routes: Routes = [
  {
    
      path: '', redirectTo: 'app-cust-cart', pathMatch: 'full' 
      
      },



  
  {
    path:'app-generate-invoice',
    component: GenerateInvoiceComponent
  },
  {
    path:'app-cashondelivery',
    component: CashondeliveryComponent
  }
  ,
  {
    path:'app-carddetails',
    component: CarddetailsComponent
  }
  ,
  {
    path:'app-cust-cart',
    component: CustCartComponent
  } ,
  {
    path:'app-invoice-bill',
    component: InvoiceBillComponent
  } 
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
