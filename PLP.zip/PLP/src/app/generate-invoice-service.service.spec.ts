import { TestBed } from '@angular/core/testing';

import { GenerateInvoiceServiceService } from './generate-invoice-service.service';

describe('GenerateInvoiceServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GenerateInvoiceServiceService = TestBed.get(GenerateInvoiceServiceService);
    expect(service).toBeTruthy();
  });
});
