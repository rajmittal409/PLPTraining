import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Order } from './Beans/Order';
import { AccountDetail } from './Beans/AccountDetail';
import { Customer } from './Beans/Customer';
import { Invoice } from './Beans/Invoice';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GenerateInvoiceServiceService {
  http: HttpClient;
  coupons;
  public api = '//localhost:6799';
  order: Order
  inventoryArray:Observable<object>[] = [];
  tempInventary;
  invoiceId;
  couponDiscount: number = 0;
  discountPercent: number = 0;
  finalAmount:number=0;
  amount: number;
  cart;
  discount;
  orderArray: Observable<object>[] = [];
  coupon: number[] = []
  couponCode;
  temp = 0;
  temp1=0;
  tempData;
  constructor(http: HttpClient) {
    this.http = http;
  }


  applyCoupon(coupon: String) {
    if(coupon==""){
      return;
    }
    return this.http.get(this.api + '/customer/generateCoupon/' + coupon)
  }

  applyDiscount(productId: Number) {
    return this.http.get(this.api + '/customer/applyDiscount/' + productId)
  }
  checkQuantity(productId: Number, quantity: Number) {
    return this.http.get(this.api + '/customer/checkAvailabilityOfProduct/' + productId + "/" + quantity)
  }

  generateInvoice(customerId: Number, adminDiscount: Number, finalAmount: Number) {
    return this.http.post(this.api + '/customer/generateInvoice/' + customerId + "/" + adminDiscount + "/" + finalAmount, null)
  }

  generateOrder(productId: Number, invoiceId: Number) {
    for (let order of this.cart) {
      console.log(order)
      let data3 = this.applyDiscount(order.products.productId);
      data3.subscribe(data4 => {
        console.log(data4);
        this.discount = data4;
        let totalAmount = order.productQuantity * order.products.productPrice
        console.log( totalAmount - totalAmount * this.discount / 100)
        this.order = new Order(111, totalAmount * this.discount / 100, order.productQuantity, totalAmount - totalAmount * this.discount / 100, null, null);

        this.tempData = this.http.post(this.api + '/customer/generateOrder/' + order.products.productId + "/" + invoiceId, this.order)
        this.tempData.subscribe(data4 => {
          this.orderArray[this.temp++] = data4
        })
      })
    }this.temp=0;
      return this.orderArray
    
  }

  getPrice(productId: Number) {


    return this.http.get(this.api + '/customer/getPrice/' + productId)
  }


  getCoupons() {


    return this.http.get(this.api + '/customer/fetchCoupons')
  }

  getCart(customerId: Number) {


    return this.http.get(this.api + '/customer/getCart/' + customerId)
  }

  addCard(accountDetails: AccountDetail, customerId: Number) {
    return this.http.post(this.api + '/customer/addCard/' + customerId, accountDetails)
  }

  updateCard(cardNo: Number, finalAmount: Number) {
    return this.http.put(this.api + '/customer/updateAccountDetail/' + cardNo + "/" + finalAmount,null);
  }

  fetchInvoice(invoiceId: Number) {
    return this.http.get(this.api + '/customer/getInvoice/' + invoiceId);
  }
  fetchOrders(invoiceId: Number) {
    return this.http.get(this.api + '/customer/getOrders/' + invoiceId);
  }


  fetchAccount(cardNo: Number) {
    return this.http.get(this.api + '/customer/getAccountDetail/' + cardNo);
  }
  updateRevenue(invoiceId: Number) {
    return this.http.put(this.api + '/revenue/fetching/' + invoiceId, null);
  }
  accountUpdate(cardNo: number) {
    return this.http.put(this.api + '/accountUpdate/' + cardNo, null);
  }
  updateInventary() {
    for (let order of this.cart) {
      console.log(order)
     
      this.tempInventary=this.http.put(this.api + '/customer/updateInventory/' + order.products.productId + '/' + order.productQuantity, null);
      this.tempInventary.subscribe(tempInventar=>{
        this.inventoryArray[this.temp1++]=tempInventar;
      })
    
    }
    return this.inventoryArray
  }
}
