import { Customer } from './Customer';

export class AccountDetail{
    cardNo:number;
    cardholderName:String;
    cvv:String;
   month:String;
   year:String;
    customer:Customer;
balance:number;
    constructor( cardNo:number,
        cardHolderName:String,
        CVV:String,
       balance:number,
        month:String,
   year:String
    ){
        this.cardholderName=cardHolderName;
        this.cardNo=cardNo;
        this.month=month;
        this.year=year;
        this.cvv=CVV;
      this.balance=balance
    }
}