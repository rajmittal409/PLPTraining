import { Customer } from './Customer';

export class Invoice{
    invoiceId:number;
    adminDiscount:number;
    finalAmount:number;
    customer:Customer;

    constructor(invoiceId:number,
        adminDiscount:number,
        finalAmount:number,
        customer:Customer){
            this.adminDiscount=adminDiscount;
            this.customer=customer;
            this.finalAmount=finalAmount;
            this.invoiceId=invoiceId;
        }
}