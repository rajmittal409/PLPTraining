import { Status } from './Status';

export class Merchant{
    merchantId:number;
    merchantName:String;
    merchantPassword:String;
    merchantContactNo:String;
    merchantGSTNo:String;
    merchantCompanyName:String;
    merchantStatus:Status;

    constructor( merchantId:number,
        merchantName:String,
        merchantPassword:String,
        merchantContactNo:String,
        merchantGSTNo:String,
        merchantCompanyName:String,
        merchantStatus:Status){
            this.merchantCompanyName=merchantCompanyName;
            this.merchantContactNo=merchantContactNo;
            this.merchantGSTNo=merchantGSTNo;
            this.merchantId=merchantId
            this.merchantName=merchantName;
            this.merchantStatus=merchantStatus;
            this.merchantPassword=merchantPassword;
            
        }
}