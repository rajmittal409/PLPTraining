import { Customer } from './Customer';
import { Product } from './Product';

export class Cart{
    cartId:number;
    customer:Customer;
    products:Product;
    productQuantity:number;

    constructor(  cartId:number,
        customer:Customer,
        product:Product,
        productQuantity:number){
            this.cartId=cartId;
            this.customer=customer;
            this.products=product;
            this.productQuantity=productQuantity
        }

}