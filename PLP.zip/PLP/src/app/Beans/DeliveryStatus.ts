import { OrderStatus } from './OrderStatus';
import { Order } from './Order';

export class DeliveryStatus {
    id: number;
    status: OrderStatus;
    order: Order;
    deliveryDate: Date;

    constructor(id: number,
        status: OrderStatus,
        order: Order,
        deliveryDate: Date) {
        this.deliveryDate = deliveryDate;
        this.id = id;
        this.order = order;
        this.status = status;

    }
}