import { Status } from './Status';

export class Customer{
    customerId:number;
    customerName:String;
    customerPassword:String;
    customerContactNo:String;
    customerAddress:String;
    customerStatus:Status;
    customerQuestion:number;
    customerAnswer:String;
}