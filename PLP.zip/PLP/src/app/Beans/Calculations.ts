

export class Calculations{
    productId:number;
    productName:String;
    totalAmount:number;
    couponAmount:number;
    discountAmount:number;
    finalAmount:number;
stock:String;
    constructor(productId:number,
        productName:String,
        totalAmount:number,
        couponAmount:number,
        discountAmount:number,
        finalAmount:number,
        stock:String
    ){
this.couponAmount=couponAmount;
this.discountAmount=discountAmount;
this.finalAmount=finalAmount;
this.productId=productId;
this.productName=productName;
this.totalAmount=totalAmount;
this.stock=stock;
    }

}