import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GenerateInvoiceComponent } from './generate-invoice/generate-invoice.component';
import { HttpClientModule,HttpClient } from '@angular/common/http';
import { GenerateInvoiceServiceService } from './generate-invoice-service.service';
import { CarddetailsComponent } from './carddetails/carddetails.component';
import { CashondeliveryComponent } from './cashondelivery/cashondelivery.component';
import { CustCartComponent } from './cust-cart/cust-cart.component';
import { InvoiceBillComponent } from './invoice-bill/invoice-bill.component';

@NgModule({
  declarations: [
    AppComponent,
    GenerateInvoiceComponent,
    CarddetailsComponent,
    CashondeliveryComponent,
    CustCartComponent,
    InvoiceBillComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [HttpClient,GenerateInvoiceServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
